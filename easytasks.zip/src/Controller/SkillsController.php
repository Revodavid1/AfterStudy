<?php
// src/Controller/SkillslistController.php

namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;

class SkillsController extends AppController
{
    
}
?>